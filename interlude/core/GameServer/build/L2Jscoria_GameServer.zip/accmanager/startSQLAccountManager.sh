#!/bin/sh
java -Djava.util.logging.config.file=console.cfg -cp lib/c3p0-0.9.1.2.jar:lib/l2scoria-am-0.2.jar:lib/mysql-connector-java-5.0.7-bin.jar ru.sword.accountmanager.SQLAccountManager
